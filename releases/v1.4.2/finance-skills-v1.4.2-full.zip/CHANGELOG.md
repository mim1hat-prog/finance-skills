# Changelog

## 1.4.2 — 2026-11-25

- Generate the GitHub README chart and numerical summary together so the main-page graph cannot silently disappear or point to a frozen release.
- Reject moving the generated coverage block below the quick start, and keep the linked chart relative to the current repository branch.
- Show actual retained observation periods and retrieval timestamps beside the repository version, separating data acquisition from package publication.
- Require maintenance to check the live main-page graph against current source hashes and publish coherent source, graph and README updates together.
- Preserve finance methods, benchmark values, historical releases and the absence of donation links in current presentation.

## 1.4.1 — 2026-11-25

- Put the generated coverage graphic at the top of the GitHub README and before the static catalogue's skill list.
- Add a compact dot. header, clearer navigation and prominent platform/package downloads, informed by uv, FastAPI and Ollama.
- Generate the README's numerical fallback from the same measured inventory as the chart so future updates cannot silently leave stale counts.
- Remove the donation footer from the current catalogue template and generated page; keep frozen historical releases unchanged.
- Document authenticated Git publication with verified public identities and an explicit expected-head lease for an authorized history repair.
- Preserve canonical finance instructions, public benchmark observations and prior frozen packages.

## 1.4.0 — 2026-11-25

- Add a task-first quick start and independently invented reconciliation example, with an exact expected result.
- Generate descriptive skill/data coverage statistics, explicit denominators and gaps, source hashes, Markdown/JSON reports and a dot-styled SVG figure.
- Generate a complete static skill catalogue, accurate title/description and SoftwareSourceCode metadata; prepare relevant GitHub topics without claiming settings or a deployed website.
- Add support and conduct guidance, synthetic-only issue templates, a PR checklist and a proposed native evaluation protocol informed by reviewed public repositories.
- Add a read-only public commit-identity guard, separate from source/release content scanning. Unresolved identity findings block publication through tools that cannot control commit identity.
- Preserve canonical finance methods, benchmark observations and every earlier release archive. Native efficacy, adoption and search ranking remain unmeasured.

## 1.3.0 — 2026-11-25

- Add a Markdown-only download containing all 29 Copilot and 29 Gemini instruction bodies, the Excel agent profile and a short start guide: 60 `.md` files ready to copy and paste.
- Remove YAML headers in this generated format while retaining the complete edition notes, shared controls and skill procedures. Keep its exact inventory and checksums outside the ZIP.
- Add the Markdown ZIP as a fifth versioned release download. Continue validating earlier four-archive release manifests and preserve all published v1.1.0 and v1.2.0 bytes.
- Keep canonical finance procedures, benchmark observations and research records unchanged; pasted copies require manual replacement when updated.

## 1.2.0 — 2026-11-25

- Add connected reporting, provision reconciliation, FX/allocation preflight and shared benchmark lookup: 29 canonical skills and 58 native packages.
- Share evidence, run-context, residual, artifact-preservation and action-state controls across both editions; strengthen targeted retrieval and independent checking while respecting host limits.
- Add read-only workflow schemas and helpers, with independently invented failure cases for incomplete explanations, protected-record/schema regressions and detailed readback differences.
- Add a public benchmark dataset, explicit collector and local read-only OpenAPI 3.1.2 service. Retain ECB and selected World Bank observations, original/derived lineage, rights and immutable vintages; keep restricted or unverified sources visibly unavailable.
- Add the canonical research registry, correction/retraction checks and exact source-to-skill/test links; unresolved research candidates are not active method support.
- Add a 29-entry tool and capability inventory with availability, support and evidence requirements.
- Add generated CFF citation metadata, documented repository standards, contribution guidance, data boundaries and an offline release gate that also checks nested packages.
- Preserve all v1.1.0 release files and the existing native import shapes. Existing imports require replacement or Refresh; no public API deployment or enterprise connector activation is included.

## 1.1.0 — 2026-11-25

- Add the Excel agent's enterprise-first, concise-output instructions as `excel-agent-core` and generated plain text for an existing agent's Instructions field.
- Apply its default output rules to both editions and remove conflicting mandatory audit tables, registers and extra-sheet instructions while retaining internal validation and material findings.
- Generate 25 skills in both editions, 50 individual native-import ZIPs, and Copilot, Gemini and combined transport bundles with exact manifests.
- Add prominent download-all and Instructions links to the dot catalogue, including edition switching and no-JavaScript fallbacks.
- Add versioned Copilot, Gemini, all-skills and full-project release ZIPs, release notes, SHA-256 checksums and a release index.
- Add deterministic release generation and a guard against overwriting an existing version with changed content.

## 1.0.0 — 2026-11-25

- Publish the reviewed library in `mim1hat-prog/finance-skills` with its own history and plugin-only GitHub maintenance.
- Establish a dedicated finance library from the 16 portable work skills published in dot-agent-toolsuite.
- Add eight specialist skills for ingestion, evidence, mappings, close, cash, scenarios, extraction and diagrams.
- Generate separate Copilot and Gemini editions, 48 individual ZIPs, Gem-ready text and exact package manifests.
- Add an original dot-styled catalogue, source provenance and task prompts.
- Add standard-library CSV profiling/reconciliation and a quantity/rate/FX bridge, plus optional read-only workbook and DuckDB helpers.
- Add a version-aware folder copier, reviewed upstream pins, safe source acquisition and read-only update checks.
- Document native import/refresh steps, optional Windows setup, account constraints and checks still requiring the target environment.
