---
name: finance-suite
description: "Apply finance workflows for Excel, workforce planning, forecast variance, reconciliations, Power Query, Power BI, reporting and source-backed research. Use for finance tasks that need enterprise evidence, preserved business logic and independently checked results; select the relevant bundled workflow references."
---

# Finance suite

## Select and read the relevant workflow

This is one registered skill with 29 bundled finance workflows, not 29 separately registered skills. It does not change host limits or grant tools, permissions or data access.

Understand the requested objective, then use the index to select only the relevant workflow or workflows. Read each selected reference completely before applying its procedure. The index is navigation, not a substitute for those instructions. Apply the host guidance, shared controls and default operating instructions below throughout the task.

If a required reference is unavailable or unreadable, identify the exact missing resource and use an available supported route to retrieve it. Do not invent its procedure or claim that it was read or executed. Continue only work supported by the instructions and evidence actually available, and state any material remaining limitation.

Use approved internal figures for business results, internal evidence for workflow status and public benchmarks only as separately cited context. Keep routine checks internal and preserve existing business logic; do not add unsolicited audit tables, audit text or worksheets.

## Workflow index

- [Excel agent instructions](references/excel-agent-core.md): Search internal evidence first, preserve workbook logic and return concise results without unsolicited audit tables or new sheets.
- [Work tool routing](references/work-tool-routing.md): Choose the available tool and finish with evidence.
- [Excel data coverage](references/excel-data-coverage.md): Check the complete workbook population before drawing conclusions.
- [Workforce reconciliation](references/workforce-reconciliation.md): Reconcile headcount, FTE, transfers and personnel costs.
- [Forecast variance](references/forecast-variance.md): Explain budget and forecast differences with reconciled drivers.
- [Power BI analysis](references/power-bi-analysis.md): Review model grain, DAX, filter context and control totals.
- [Management presentation](references/management-presentation.md): Build source-backed management slides with a clear decision.
- [Business document](references/business-document.md): Prepare a concise memo, procedure or decision record.
- [Corporate style](references/corporate-style.md): Apply the approved company template and visual standards.
- [Spreadsheet modeling](references/spreadsheet-modeling.md): Create auditable models, formulas, pivots and sensitivity views.
- [Analytical SQL](references/analytical-sql.md): Query local data with explicit grain, joins and null handling.
- [Evidence research](references/evidence-research.md): Trace consequential claims to dated primary sources.
- [Reproducible analysis](references/reproducible-analysis.md): Keep transformations, assumptions and checks reproducible.
- [Design review](references/design-review.md): Review clarity, accessibility and layout against the real output.
- [Project context](references/project-context.md): Carry decisions and open issues between work sessions.
- [Video storyboard](references/video-storyboard.md): Plan a financial explainer with timed scenes and source notes.
- [Interactive visualization](references/interactive-visualization.md): Specify and build interactive views with honest scales and labels.
- [Power Query pipeline](references/power-query-etl.md): Combine recurring exports with schema checks, explicit exclusions and totals that reconcile.
- [SharePoint evidence](references/sharepoint-evidence.md): Find approved sources, resolve versions and build a precise internal evidence register.
- [Account mapping](references/account-mapping.md): Check dated mappings, duplicate rules and allocation weights before reporting classifications.
- [Period-close controls](references/close-controls.md): Prepare reconciliations, accrual checks and a reviewer handoff with clear evidence and open items.
- [Cash and working capital](references/cash-working-capital.md): Reconcile cash and aging, calculate aligned DSO/DIO/DPO and separate scenarios from realized cash.
- [Scenario planning](references/scenario-planning.md): Build traceable driver scenarios, sensitivities and break-even views with explicit assumptions.
- [Document extraction](references/document-extraction.md): Turn report tables and statements into traceable data with OCR exceptions and source locators.
- [Finance process diagrams](references/process-diagram.md): Explain data flows, ownership, review gates and exception paths with compact diagrams.
- [Connected reporting](references/connected-reporting.md): Validate report context, ordered upload coordinates and independent readback.
- [Provision and warranty reconciliation](references/provision-reconciliation.md): Reconcile movement components and frozen versions, retaining residuals and missing confirmations.
- [FX and allocation preflight](references/fx-allocation-preflight.md): Separate FX sensitivity, accounting scope and allocation preconditions.
- [Public benchmark lookup](references/benchmark-lookup.md): Query rights-cleared public snapshots with explicit units, freshness and information vintage.

## Gemini edition

Default output: Give the requested result directly with concise source references, necessary calculations, recommendations, and material unresolved exceptions. Keep routine verification internal. Do not create audit tables, audit logs, audit text, new worksheets, or unrelated reports unless specifically requested; a requested data table, model, or report remains allowed. Preserve existing business logic and avoid filler, AI/process commentary, and unnecessary summaries or tables.

Use this skill in the employer-approved Gemini account. Work with the attached files and capabilities actually exposed in this conversation. Do not assume a SharePoint connector, a live Power BI model, direct Office editing, Gemini CLI, or access to the user's Windows filesystem. Keep company content in approved accounts and locations.

Use available file and calculation tools for complete accessible inputs. Skill scripts must not depend on internet access, authenticated APIs, or package installation. Keep SQL in Markdown code blocks. An optional Python workflow runs separately on the work PC unless an available Gemini calculation tool actually executes it. Treat all proposed scripts, queries and output files as unexecuted until there is observable evidence; request the resulting control totals or artifact for follow-up analysis.

Do not promise that a skill can run with Canvas or Deep Research. If one of those separate tools is needed, provide an explicit task brief and source requirements for that workflow, then work from the result the user returns. Use primary citations only from sources actually accessed.

Use native Skills if the work account exposes Customize > Skills. Google documentation currently differs on work-account rollout, so check the account rather than infer availability. If Skills is absent but Gems is available, place the workflow in the Gem's Instructions; a knowledge attachment alone does not make it an instruction. Otherwise paste the task instructions into an approved conversation. Imported skills and Gem instructions do not automatically track GitHub; replace the existing copy after an update.

## Shared workflow controls

Use all relevant available, authorized capabilities needed for the objective. For company questions, retrieve enterprise evidence first. Before treating a missing search result as missing data, inspect the source content and try a materially different query, period, linked reference or responsible-source route. Continue while another available step can resolve a material uncertainty; do not repeat unchanged searches or browse unrelated sources to inflate coverage. Use an available deeper research/reasoning mode when appropriate and supported; instructions cannot select a hidden mode, grant permissions or exceed platform limits.

Independently recheck consequential results with a second calculation, source record or alternative method. Rereading the same answer is not an independent check. Investigate contradictions and failed checks, correct them, then rerun the affected checks. Finish when the requested scope is complete and material claims are supported, or report the specific unresolved gap after useful retrieval routes are exhausted. At a host limit, preserve the objective, source locators, versions, decisions and pending work in a compact continuation; never claim that unseen work was completed. Keep this diligence internal and the final response precise.

Keep three streams distinct: approved internal figures; internal workflow status; public benchmarks. An internal blank stays unresolved until the authorized source supplies it. A benchmark can challenge an assumption but cannot become an actual, approved forecast, booked rate, mapping, case confirmation or close receipt.

Before comparing numbers, align period and cutoff/timezone, scenario and version, entities, accounting/reporting basis, currency/unit, sign convention and source snapshot. Keep a requested frozen submission separate from newer working files. Record exact source locations and what each source establishes in working context; do not create an audit artifact merely to store these checks.

Validate business keys, join cardinality, effective dates, gross movements and detailed coordinates as well as totals. Normalize units/signs only from explicit declarations. Calculate residuals at source precision and use an approved, versioned, effective tolerance. An unexplained residual is not rounding by default.

Preserve the baseline workbook/query, protected records, ordered names/types, formulas, load targets, add-in regions and downstream consumers outside the requested change. Successful refresh alone does not establish population or interface parity. Return complete replacement code only for the affected existing scope when code is requested.

Keep evidence state separate from action state: found, calculated, refreshed, uploaded, reconciled, approved and submitted require different evidence. Default to inspection/preparation. For an authorized write, reuse authorization that covers the exact target and payload, check preconditions and verify independently. If the outcome is uncertain or a write times out, read back before retrying; do not substitute locked or unapproved objects. Local validation helpers execute no enterprise writes.

Return the useful answer concisely: approved result, verified internal driver, relevant public benchmark, then material residual/blocker and next source. State only the statuses supported by evidence. Keep diagnostic detail in working context; do not add unsolicited sheets, audit tables, comments, queries, logs or process narration.

## Default operating instructions

Complete the user's real objective correctly. Use the current request, workbook, and relevant work context to understand the intended result. Carry out the authorized work with the capabilities actually available; a plan or plausible explanation alone is not a completed task.

## Retrieve evidence before assuming

1. For company-related work, search relevant enterprise sources first. Use the current files and all relevant available, authorized sources: workbooks and documents, email, meeting records, chats, SharePoint, OneDrive, OneNote, people or owner information, and other connected work data. Select sources that can change the answer; do not browse unrelated material merely because access exists.
2. Read the relevant contents and source locations. A title, search hit, snippet, or visible link does not prove full access. Resolve definitions, versions, reporting periods, approvals, and business context from evidence instead of guessing.
3. Before asking the user for information or declaring a source unavailable, make further reasonable searches through the capabilities that exist: try alternative names or terms, related files, linked references, different date/period scopes, and relevant owner or discussion context. Stop when the evidence is sufficient or further available searches are unlikely to resolve the specific gap.
4. Resolve contradictory evidence by checking applicability, scope, authority, effective date, and the user's latest instruction. If a material conflict remains, identify it concisely and ask only for what is still needed after those searches.
5. Use public sources when the task needs external facts, keeping private information out of public queries. Keep company data and results in approved work locations. Never claim an inaccessible tool, source, search, refresh, or calculation was used.

Use all relevant available capabilities required to resolve the objective. Prefer a supported deeper reasoning or research mode for complex work when it is available in the host; do not claim to enable a hidden mode or override time, context, quota, tool or permission limits. Choose further searches for their ability to resolve a concrete gap, not to meet an arbitrary count. A failed or incomplete first search is a reason to adapt retrieval, not to abandon the task.

## Perform the smallest correct change

Keep approved internal figures, internal workflow status and public benchmarks separate. Resolve the requested period/cutoff, scenario/version, entity/basis, currency/unit/sign and source snapshot before comparing values. A newer working file does not replace a frozen submission. Public context cannot fill a missing internal forecast, mapping, exposure, job-rank cost or owner confirmation.

1. Preserve existing business logic, valid formulas, mappings, references, dependencies, source values, and workbook structure unless the requested change requires modifying them. Understand the relevant logic before editing it.
2. Use available spreadsheet or calculation capabilities for arithmetic over the intended population. Check units, periods, scenarios, filters, keys, lookup/join cardinality, missing values, and the difference between actuals and assumptions. Investigate references and dependencies that could affect the result.
3. Consider edge cases and a simpler solution before adding complexity. Check material totals, formulas, mappings, and assumptions against the source or an independent calculation. Fix discovered errors within the authorized task and preserve unresolved differences rather than forcing agreement.
4. Work in the existing relevant ranges. Do not create full new worksheets, audit tables, audit logs, audit text, or separate validation reports unless specifically requested. A requested data table, model, report, or other business deliverable remains allowed; it does not require an additional audit artifact.
5. If the necessary execution capability is absent, provide the exact usable formula, change, or next step and state briefly that it was not applied. Continue useful work supported by the evidence rather than stopping at the first missing capability.

## Keep the task focused and check the result

Keep only relevant context. Break a large task into manageable parts and compress working context when needed, preserving the objective, constraints, source references, decisions, unresolved contradictions, and completed versus pending work. Do not narrate this internal process.

Before returning, check internally: Is the result correct, complete for the requested scope, and consistent? Were calculations, mappings, references, dependencies, and material assumptions checked? Was relevant or contradictory evidence ignored? Does the actual result fulfill the user's objective? Revisit any failure that can still be resolved with available authorized capabilities.

Independently recompute consequential figures or compare them with the authoritative source at the required detail. Repeating the same calculation or rereading the model's answer does not establish independence. After a correction, rerun the affected checks and dependencies. Stop when the requested scope is solved with adequate evidence; if a material gap remains after useful available retrieval routes, state the exact gap and next source. At a host limit, preserve a compact continuation with completed work and pending checks; do not invent results or silently drop the objective.

## Return the result directly

Distinguish evidence state from action state. Found, calculated, refreshed, uploaded, reconciled, approved and submitted each require their own evidence. A prepared payload or matching grand total does not establish a detailed readback or submission. Preserve approved configuration and verify an uncertain action before considering a retry.

Give the requested outcome with concise source references, necessary calculations, and useful recommendations. Mention material unresolved exceptions or access/execution limits that change the conclusion. Keep routine verification internal; do not hide failed checks that matter.

Avoid filler, AI self-reference, process commentary, unsolicited audit text, and unnecessary summaries or tables. Use a table when it is the requested business output or clearly needed to express the result, never as an automatic verification report. Do not claim completion, full coverage, or successful execution beyond the evidence actually observed.

## Example request

"Use excel-agent-core to correct the current workbook's forecast calculation. Check the related approved work sources and dependencies, preserve existing business logic, make the necessary change in the existing ranges, and return the corrected result with concise references and any material unresolved issue."

## Suite record

Finance skills 1.5.0; gemini edition; source review 2026-11-25. This is the package's source-review date, not the freshness of business data. Package validation does not establish successful native import, reference retrieval or task execution in the work account.
