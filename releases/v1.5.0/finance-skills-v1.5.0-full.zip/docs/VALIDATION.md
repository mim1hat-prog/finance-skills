# Validation record

Checked **2026-11-26**. This record describes the evidence obtained in the build environment. It does not claim installation in a company account or execution on the Windows work PC.

## v1.5.0 complete-suite validation

The offline gate passed **161 Python tests with zero skips** and reproduced **229 generated artifacts**. Seven suite tests cover exact canonical reference contents, deterministic archives, root metadata and size limits, missing/unsafe resource paths, explicit feature flags and compatibility with individual packages. Release tests cover the new seven-archive schema, preservation of older formats and a suite payload changed after recomputing its checksums.

Both native suites contain exactly **30 files: one root `SKILL.md` and 29 Markdown workflow references**, with no nested archives. An independent PyYAML parse and direct comparison with the canonical bodies passed. The Copilot main file has 18,265 characters and its ZIP is 96,275 bytes; Gemini has 18,295 characters and a 96,302-byte ZIP. Both remain under the portable 20,000-character main-file limit. The external suite manifest records every member hash, canonical source hash, version and one registration per package.

A separate local agent read the Copilot suite and its work-tool-routing, close-controls and reproducible-analysis references, then reconciled independently invented extracts from 585.00 to 615.00 with a 30.00 difference and zero arithmetic residual. It retained both unmatched keys without inventing a mapping and left the business reasons unconfirmed. Decimal arithmetic and integer-hundredths checks agreed. This is one local routing example, not a Copilot or Gemini execution result or a performance estimate.

Catalogue DOM checks passed for both new suite links, existing downloads, 29 workflow rows, filters, edition switching, copy success/failure, themes and metadata. They do not establish browser layout. The previous layout limitation remains. The research registry contains 83 sources with the five pre-existing rights/correction warnings; public benchmark observations and acquisition timestamps are unchanged.

Native account import, reference access, invocation and task quality remain unverified. The public graph continues to report zero accepted native execution records. The suite is one installed skill containing multiple procedures; package validation does not establish 29 separate registrations, new permissions or automatic installed-copy refresh.

## v1.4.4 Copilot import-format validation

All 29 Copilot native packages in the inspected v1.3.0 and v1.4.3 releases were independently parsed with PyYAML 6.0.3. Each contains one root `SKILL.md`, valid name/description strings, UTF-8 without BOM and content within the documented Chat metadata and portable instruction limits. The live GitHub `excel-agent-core.zip` was also retrieved and independently checked: its required metadata is present, and it contains 13,008 instruction-file characters with a 331-character description.

The headerless Markdown bundle is a copy-and-paste format; outer transport ZIPs are not one native skill. Either could explain the reported validation error if uploaded through the wrong route. The rejected file and host were not supplied, so no specific cause or successful native import is claimed. Current Microsoft Chat, Agent Builder and Copilot Studio troubleshooting pages were directly reviewed for the new guide text and recorded as scoped references.

The offline gate passed **151 Python tests with zero skips** and reproduced **166 generated artifacts**. The registry has 81 sources with the five previously documented warnings. All 29 canonical skill files are unchanged; all 58 generated native packages differ from v1.4.3 only in their edition version record. The benchmark files retain their original bytes. No new runtime behavior or financial method was introduced.

The README, setup guides and generated bundle start guides now distinguish native upload from copy-only text and extraction of transport downloads. Current setup guides use maintained download destinations; earlier frozen packages remain unchanged. Publication is verified separately.

## v1.4.3 weekly-maintenance validation

The existing scheduling record confirmed an enabled weekly check on Wednesdays at 08:00 Asia/Tokyo, with the first weekly occurrence on 2026-12-02. Current maintainer instructions and the README now match that cadence. Daily public-data frequencies and frozen historical releases retain their original meaning.

The offline gate passed **151 Python tests with zero skips** and reproduced **166 generated artifacts**. No new test was added for this documentation-only change. The finance skill bodies, benchmark observations and acquisition dates remain unchanged. Source/release validation does not establish a successful remote push or a future maintenance run.

## v1.4.2 main-page graph validation

The offline gate passed **151 Python tests with zero skips** and reproduced **166 generated artifacts**. The complete README coverage block now owns the graph link, numerical fallback, repository version and retained source dates. Missing/wrong chart content is regenerated; stale generated bytes and a block moved after quick start fail the checks. The root image uses the current branch's asset rather than a frozen release path.

Nine focused metrics tests passed, including mixed latest observation endpoints, distinct daily/monthly groups, UTC-normalized retrieval ranges, and a changed package release date that leaves acquisition dates unchanged. The current 1200 × 841 SVG was rendered and visually inspected with no clipping or overlap. The catalogue image no longer declares an obsolete fixed height. Existing desktop/mobile browser-layout limitations remain; no new browser rendering result is claimed.

The figure reports 29 skills, workflow-test links for 8/29, native execution evidence for 0/29 and observations for 11/17 configured benchmark series. Retained ECB observations end at 2026-11-24, and World Bank monthly observations at 2026-10; their recorded acquisition timestamps are on 2026-11-25. No provider was fetched or redated by the build. The registry remains at 78 sources with the existing five warnings.

Canonical finance instructions, benchmark values and earlier frozen releases remain unchanged. The main-page maintenance check is configured separately from build execution. Local checks, a schedule and prepared Git history do not establish a successful remote publication, current upstream availability or continuous live refresh.

## v1.4.1 homepage validation

The offline artifact gate passed **149 Python tests with zero skips** and reproduced **166 generated artifacts**. Earlier frozen v1.1.0–v1.4.0 release bytes remain unchanged. Canonical finance instructions and benchmark observations were not changed.

- **Homepage:** the generated coverage figure appears before the README quick start and before the static catalogue's skill list. The compact original dot. hero was rendered with Inkscape and visually inspected. README relative links resolve. The marked numerical fallback matches the generated inventory and is checked against changed-count and malformed-marker regressions.
- **Catalogue behavior:** independent DOM checks passed for 29 skills, both editions, search/category/reset, prompt copy success and failure, themes, unique IDs, metadata and malformed-data fallback. The current README, template and generated page contain no donation link. The catalogue regression also checks coverage order and the absence of donation destinations.
- **Evidence:** the registry has 78 records, including three new software-project references used only for presentation decisions. It records 77 active sources and one candidate. The five existing source-rights/correction warnings remain visible. No native execution, model accuracy, adoption or ranking claim was added.
- **Rendering limitation:** a local Chromium launch with alternate process/shared-memory flags failed before page navigation because the environment denied a socket operation. No desktop/mobile browser layout validation is claimed. SVG inspection and DOM execution are separate checks.
- **Publication:** source/package checks and safe Git author/committer checks remain separate. Authenticated Git transport is supported for the owner's authorized history repair with an explicit expected-head lease. No successful authentication, remote push, settings change or deployment is implied by this validation record.

## v1.4.0 artifact validation

The artifact gate passed **148 Python tests with zero skips** and verified **165 deterministic generated files**. Existing v1.1.0, v1.2.0 and v1.3.0 snapshots passed integrity checks and remain unchanged. Canonical finance skill bodies and public benchmark observations were not changed. These are package-validation results; remote publication is verified separately.

- **Coverage:** six focused tests passed for deterministic measurements, source hashes, exact reference use, missing evidence, latest-vintage selection, synthetic exclusion, empty denominators and metadata mismatch rejection. The generated inventory reports 29 skills, declared workflow-test links for 8/29, no recorded native execution evidence, 75 source records (74 active, one candidate), 11/17 configured public series with observations, 116 original rows and 51 derived rows. These are descriptive counts, not model-performance measures.
- **Discovery and community:** six focused tests passed for complete static HTML, text/JSON-LD escaping, accurate metadata, invalid profile/template rejection, safe output handling and exact community-file inclusion. Independent DOM checks on the actual v1.4.0 files passed for all 29 rows, Gemini routing, search/filter/reset, deep links, copy success/failure feedback, theme state, unique IDs, version links and malformed-data fallback. All 29 skills and prompts remain readable without JavaScript. Arbitrary `.github` files and workflows are excluded from release collection; linked parents are rejected.
- **Examples and sources:** the existing invented CSVs reconciled exactly from 350.30 to 365.35 with a 15.05 difference and zero residual, retaining both unmatched keys. Nineteen new primary source records document repository practices, discovery, proposed evaluation and metadata privacy. No new native efficacy or public-feed refresh is claimed.
- **Presentation:** the coverage SVG and original 1280 × 640 social-preview SVG were rendered and visually inspected. The prepared social PNG is 73,337 bytes. System Chromium exited before opening the local catalogue, so desktop/mobile browser layout remains unverified. DOM and SVG inspection do not substitute for that check.
- **Privacy boundaries:** the current source/package scan covered 4,367 expanded entries and 1,031 archive inspections with no findings under the separate private marker policy. A separate historical review examined all six published main commits and 812 distinct file blobs; source and release contents passed. Git author/committer metadata had an identity finding. The read-only identity guard's six tests passed, and the release CLI can now fail explicitly on an external commit export. A successful artifact gate does not establish a clean Git identity or authorize publication.

No repository settings, search ranking, user-base growth, GitHub Pages deployment or third-party listing is claimed. The prepared metadata describes settings to apply separately. Identity remediation requires a separate authorized route because the available connector cannot select author and committer fields. Raw review exports and remediation evidence stay outside the public project.

## Previous validation: v1.3.0

The Markdown-only download contains **60 `.md` files**: 29 complete Copilot instruction bodies, 29 complete Gemini bodies, the canonical Excel agent profile and a start guide. The 310,404-byte archive has no YAML frontmatter, scripts, datasets, JSON members or nested ZIPs. Every skill body matched its generated edition after removing only the YAML header and normalizing the final newline. The external inventory matched all file sizes and SHA-256 hashes; repeated builds produced identical bytes.

The integrated offline gate ran **130 Python tests with zero skips**, including the focused Markdown packaging test and three new release compatibility cases. The current build has **160 deterministic generated files**. Tests exercised a transition from legacy four-archive releases to the new five-archive format, preserving earlier bytes and modification times; unknown schema versions, incorrect inventories and unsupported feature flags were rejected. Existing v1.1.0 and v1.2.0 snapshots passed their integrity checks.

Canonical finance instructions, research records and benchmark observations were unchanged. The gate revalidated the existing dataset/API, research references, workflow contracts and nested publication inventory with no publication findings, including the separate private marker policy. This packaging check does not establish import, activation or a task result in Copilot/Gemini. The source-review dates retain their existing meaning; no new upstream review is claimed.

## Previous release: v1.2.0

The current library contains **29 canonical skills, 58 individual native ZIPs and 158 deterministic generated files**, including the Excel Instructions profile, three transport bundles, tool inventory, workflow contracts and citation metadata. All generated files matched their sources. The largest native instruction file was 15,746 bytes, within the project's portable ceiling.

The integrated offline gate ran **126 Python tests with zero skips**. The environment had Python 3.12.14, openpyxl 3.1.5 and DuckDB 2.0.1; optional dependency tests actually executed. The release helper's isolated CLI test was updated to copy its new local catalogue dependency, then passed. No provider calls or enterprise actions run as part of this gate.

- **Workflow controls:** 21 focused tests passed. An independent reviewer reran all original reproductions after corrections. Duplicate explanations, blank evidence/owners, invalid timestamp offsets, changed artifact scale/sign, mismatched allocation receivers and prior-run evidence for a different target or payload now block or reject. Valid controls remain valid. A separate synthetic skill task retained an unexplained reserve difference of 50 after two approved components explained 320 of a 370 difference; the newer unsubmitted draft did not replace the submitted baseline.
- **Benchmarks:** 20 focused tests passed. Independent reproductions confirmed that a request starting before cutoff cannot make later-arriving bytes available early, a later refresh receipt cannot leak into historical status, and relabeling a derived series cannot bypass formula/input checks. Additional checks cover mixed timezone offsets, strict timestamp rejection, partial months, index rebases, reversed FX, outages, rights and credential redaction.
- **Dataset and API:** 17 catalogue series, two real public snapshots and two separate synthetic vintages passed schema, CSV, inventory and hash checks. The real snapshots contain 119 ECB rows and 48 World Bank rows. Replaying parsers against the saved public source bytes reproduced the complete snapshots and identical IDs. Seed validation receipts record the later offline validation time, separately from source acquisition. All four OpenAPI routes passed response validation; a real loopback GET/POST check passed and the server stopped.
- **Research and standards:** 56 registry records map to 29 skills, with no unresolved reference errors. All 23 registry tests passed. The M4 paper remains an inactive candidate while its erratum requires review. BOJ and selected upstream redistribution restrictions remain explicit. `CITATION.cff` passed an independent check against the official CFF 1.2.0 draft-07 schema; data/workflow schemas use 2020-12 separately.
- **Publication boundary:** the public inventory and nested packages passed the heuristic scan, including an additional private marker policy stored outside the project. The one exception is bound to the exact hash of an already published synthetic invalid-URL test; it cannot exempt another file, changed bytes, private links or other finding categories. The previous v1.1.0 release files passed their integrity checks and remain unchanged.
- **Catalogue behavior:** DOM checks passed for the actual 29-entry v1.2.0 data, edition routing, search/filter/reset, example-copy feedback, theme state, fallbacks and version-derived download links. This does not establish browser layout. Presentation code and dot assets were retained; native desktop/mobile rendering remains unverified in this environment.

`scripts/check_release.py` is the offline pre-release command. After freezing, `--require-release` additionally requires exact current release bytes and indexes. The full ZIP deliberately excludes nested release history and can run the default gate independently. Remote publication is verified separately from this local record; a GitHub Release object or native account installation is not implied.

## Historical evidence: v1.1.0 and earlier

The following results describe prior published versions. Their original counts and limitations are retained for traceability.

### Automated checks actually run

| Check | Observed result |
| --- | --- |
| Canonical skills and both generated editions | 25 source skills, 50 standalone ZIP packages; names, frontmatter, size and independent-resource rules passed |
| Deterministic build | 135 generated files reproduced; generated bytes and SHA-256 package manifests agree |
| Python tests | 48 tests passed with no skips in the tested environment |
| Excel agent profile | Plain text derives exactly from the canonical skill body; both native editions retain the host-specific notes |
| Download-all bundles | Copilot, Gemini and combined ZIPs have exact inventories, entry hashes and deterministic bytes; nested native packages each contain one root SKILL.md |
| Release generation | Tests cover exact four-archive contents/checksums, deterministic bytes, stable SemVer ordering, immutable existing versions, prior-version preservation, current-build drift and non-writing verification, including a clean CLI run without new Python cache files |
| Full-project boundary | Explicit public project roots and file types; private/runtime/cache/unlisted files and release snapshots excluded; unsafe paths, case collisions and symlinks rejected |
| Optional libraries | DuckDB 2.0.1 and openpyxl 3.1.5 were available for their tests; Python 3.12.14 on Linux |
| CSV controls and reconciliation | Full synthetic populations, malformed records, duplicate grain, leading-zero keys, finite exact decimals, unmatched records and no-overwrite behavior checked |
| Quantity/rate/FX bridge | Known example reconciles exactly; supported numeric-extreme regression has zero residual |
| Workbook audit | Read-only input unchanged; formula caches, stored error, hidden sheet and a workbook without declared dimensions checked |
| DuckDB profile | CSV/Parquet controls; malformed rows cannot move the header; explicit dialect supports BOM/CRLF/quoted newline; key named `n` does not collide with aggregates |
| Edition copier | Preview, apply, repeat installation, customized-file preservation, checksum/source-change refusal and destination-link revalidation checked |
| Windows Git bytes | A real temporary Git checkout with `core.autocrlf=true` preserved hashed Markdown and ZIP bytes using `.gitattributes` |
| Upstream source acquisition | All four requested archive hashes verified; 16,165 archive blobs matched the pinned Git files with zero mismatches |
| Archive boundaries | Traversal, Windows names, case collisions, symlinks, size limits, checksums, existing files and non-execution behavior checked |
| Update checker | Rate limits and blocked document redirects were recorded as unavailable; pins stayed unchanged |
| Original GitHub publication | All 193 files published on the Somamill toolsuite finance branch matched their local Git blob hashes |
| Work-account publication | Initial import `23277e2768d8267cb5b885be229d473cce802e64` on `mim1hat-prog/finance-skills` main matched all 193 local file hashes, including 48 ZIP packages |

The test count includes 16 upstream-helper cases. Package validation does not prove that a model will follow every instruction. Optional tests intentionally skip when their dependencies are absent; inspect the run output before describing them as passed.

Release tooling tests use isolated temporary projects. The published release includes its exact project-file inventory and SHA-256 checksums in `releases/v1.1.0/manifest.json`; remote publication is verified separately from local packaging. No GitHub Release object or tag is claimed.

### Independent finance task checks

For the new Excel profile, a fresh agent received the relevant skill files, a raw synthetic request to correct a November Personnel total, an editable JSON workbook cell model and exported internal-source fixtures. It resolved an obsolete draft against the approved definition and final export. It corrected benefits from **EUR 18,000 to EUR 21,000**, retained the existing Personnel and Opex formulas, and updated their evaluated totals to **EUR 141,000 and EUR 167,000**. Only the existing workbook cell model changed; no worksheet, audit table, log or extra output file was created. The result was independently checked against the supplied fixture. This tests instruction behavior with synthetic local exports, not live enterprise retrieval, a native Copilot/Gemini import or Excel recalculation.

A fresh agent received only the relevant skill files and raw synthetic work requests. It quarantined overlapping mappings and an incomplete 95% allocation without normalizing or dropping the unresolved amount. Its bridge reconciled **320 source = −30 mapped + 350 unresolved**.

For working capital, it calculated an available **15-day** two-point-average DSO, declined to fabricate missing average balances, and separately identified a **21-day** group closing-balance proxy. A five-day improvement of **166.67 JPY-thousand** was labeled a modeled potential release, not received cash or a recurring monthly benefit.

An independent code review identified six edge issues. All six original reproductions were rerun after correction: CSV header inference, a key/count alias collision, unsized workbooks, a destination symlink introduced after preview, Git line endings and extreme decimal precision. Each reproduction now behaves as intended. Native Windows junction and OneDrive behavior were not exercised by those checks.

### Catalogue checks

The original catalogue passed DOM execution checks for edition-specific links, search, category selection, empty/reset behavior, focus restoration, example-prompt copy feedback with a mocked clipboard, theme persistence, unique IDs, visible control labels and malformed-data recovery. JavaScript syntax and SVG XML checks passed.

The generated **25-entry, v1.1.0** catalogue additionally passed focused DOM execution checks for the combined download, edition-following bundle label/path/filename, Gemini deep link, Instructions profile, extraction text, no-JavaScript and malformed-data fallback links, dynamic count, unique IDs and the full-release URL derived from the catalogue version. All three current bundle destinations and the profile existed. The versioned release destination is checked during final packaging/publication.

Impeccable's static detector returned no findings on the final product frontend files. Eight actual foreground/background token pairs passed 4.5:1; the lowest checked pair was 5.70:1. This is a token-pair check, not a complete accessibility certification.

Hallmark static review retained one finding in an unchanged vendored `.dot-button:disabled` rule. The catalogue does not use that class; product disabled states are explicitly overridden. Mixed light/dark token resolution and a numeric-selector match also required manual interpretation. These are documented detector limitations, not a claim of a clean full Hallmark pass.

**Desktop/mobile catalogue visual review is blocked in this environment.** Local Chromium failed before navigation with a socket-permission error. The cloud browser's URL policy rejected a local-file preview. No rendered catalogue screenshot or full browser-layout pass is claimed. The static catalogue can be reviewed locally using the Windows guide; it has not been deployed as a public website.

The original GitHub README on the Somamill toolsuite finance branch was separately inspected in a desktop browser after publication. Its dot banner, edition badges, navigation and introductory layout rendered correctly. That check covers the GitHub README, not the interactive catalogue or a mobile layout.

## Checks still requiring the target environment

- Native import, explicit skill invocation and a representative task in the actual approved Copilot/Gemini account.
- Windows 11 execution with the owner's installed Python version and approved packages.
- Office-created OneDrive folder behavior, syncing, Refresh and locked-file handling.
- Power BI model correctness and service refresh using the actual approved data/model.
- Real SharePoint permissions, source coverage and document versions.
- Desktop/mobile rendered catalogue inspection and any employer-template layout checks.

No original Claude-mem worker, HyperFrames renderer or paid Valyu integration was installed on the work PC. Source acquisition, repository design tooling, portable instruction adaptation and native account activation are recorded separately.

## Work-account migration

Published on **2026-11-25** to `mim1hat-prog/finance-skills`, branch `main`,
through the ChatGPT GitHub plugin connected as `mim1hat-prog`. The import uses
only the reviewed tracked tree and follows the destination's starter README
commit. Original source-pack and dot design-kit provenance, licences and
package content are preserved; the older toolsuite history was not imported.

All 193 destination files and their modes matched the staged Git hashes after
the initial import, including all 48 individual skill packages. The destination
README was read through the plugin. No cloud-browser authentication or visual
inspection was performed for this destination; the earlier visual check covers
the original publication described above. Native work-account imports remain
checks for the actual approved Copilot/Gemini account.
