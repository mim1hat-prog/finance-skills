# Start here: copy and paste

Finance skills 1.4.3 · Markdown-only edition

This ZIP contains 29 Copilot skill files, 29 Gemini skill files, Excel agent instructions and this guide. Every file is Markdown (.md).

## Use a skill

1. In Windows File Explorer, choose Extract All for this ZIP.
2. Choose the copilot or gemini folder, then open the skill you need in VS Code or Notepad.
3. Press Ctrl+A, then Ctrl+C to copy the entire file. YAML headers have already been removed.
4. Paste into your available agent or Gem Instructions field, or into an approved conversation. Save the instructions if the host provides that option, then supply your task and relevant files.

Use one relevant workflow at a time. These are plain instructions for copying; the ZIP is not a native skill import. Pasting does not enable unavailable tools or increase host limits.

## Your Excel agent defaults

Copy all of EXCEL-AGENT-INSTRUCTIONS.md into the Instructions field you already use for your Excel agent. It is the shared profile; the copilot and gemini folders contain the complete edition-specific workflows.

## Updates

Downloaded and pasted copies do not update automatically. Download a newer version and replace the relevant instructions, preserving any approved company additions in your private account.

[Repository and downloads](https://github.com/mim1hat-prog/finance-skills)
