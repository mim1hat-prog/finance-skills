---
name: fx-allocation-preflight
description: "Review FX sensitivities, accounting FX scope and allocation preconditions without conflating them. Use for rate-direction errors, changed exposure or opportunity/risk scope, original versus replicated postings, sender/receiver sets, effective weights, locked masters and uncertain prior runs."
---

# FX and allocation preflight

## Gemini edition

Default output: Give the requested result directly with concise source references, necessary calculations, recommendations, and material unresolved exceptions. Keep routine verification internal. Do not create audit tables, audit logs, audit text, new worksheets, or unrelated reports unless specifically requested; a requested data table, model, or report remains allowed. Preserve existing business logic and avoid filler, AI/process commentary, and unnecessary summaries or tables.

Use this skill in the employer-approved Gemini account. Work with the attached files and capabilities actually exposed in this conversation. Do not assume a SharePoint connector, a live Power BI model, direct Office editing, Gemini CLI, or access to the user's Windows filesystem. Keep company content in approved accounts and locations.

Use available file and calculation tools for complete accessible inputs. Skill scripts must not depend on internet access, authenticated APIs, or package installation. Keep SQL in Markdown code blocks. An optional Python workflow runs separately on the work PC unless an available Gemini calculation tool actually executes it. Treat all proposed scripts, queries and output files as unexecuted until there is observable evidence; request the resulting control totals or artifact for follow-up analysis.

Do not promise that a skill can run with Canvas or Deep Research. If one of those separate tools is needed, provide an explicit task brief and source requirements for that workflow, then work from the result the user returns. Use primary citations only from sources actually accessed.

Use native Skills if the work account exposes Customize > Skills. Google documentation currently differs on work-account rollout, so check the account rather than infer availability. If Skills is absent but Gems is available, place the workflow in the Gem's Instructions; a knowledge attachment alone does not make it an instruction. Otherwise paste the task instructions into an approved conversation. Imported skills and Gem instructions do not automatically track GitHub; replace the existing copy after an update.

## Shared workflow controls

Use all relevant available, authorized capabilities needed for the objective. For company questions, retrieve enterprise evidence first. Before treating a missing search result as missing data, inspect the source content and try a materially different query, period, linked reference or responsible-source route. Continue while another available step can resolve a material uncertainty; do not repeat unchanged searches or browse unrelated sources to inflate coverage. Use an available deeper research/reasoning mode when appropriate and supported; instructions cannot select a hidden mode, grant permissions or exceed platform limits.

Independently recheck consequential results with a second calculation, source record or alternative method. Rereading the same answer is not an independent check. Investigate contradictions and failed checks, correct them, then rerun the affected checks. Finish when the requested scope is complete and material claims are supported, or report the specific unresolved gap after useful retrieval routes are exhausted. At a host limit, preserve the objective, source locators, versions, decisions and pending work in a compact continuation; never claim that unseen work was completed. Keep this diligence internal and the final response precise.

Keep three streams distinct: approved internal figures; internal workflow status; public benchmarks. An internal blank stays unresolved until the authorized source supplies it. A benchmark can challenge an assumption but cannot become an actual, approved forecast, booked rate, mapping, case confirmation or close receipt.

Before comparing numbers, align period and cutoff/timezone, scenario and version, entities, accounting/reporting basis, currency/unit, sign convention and source snapshot. Keep a requested frozen submission separate from newer working files. Record exact source locations and what each source establishes in working context; do not create an audit artifact merely to store these checks.

Validate business keys, join cardinality, effective dates, gross movements and detailed coordinates as well as totals. Normalize units/signs only from explicit declarations. Calculate residuals at source precision and use an approved, versioned, effective tolerance. An unexplained residual is not rounding by default.

Preserve the baseline workbook/query, protected records, ordered names/types, formulas, load targets, add-in regions and downstream consumers outside the requested change. Successful refresh alone does not establish population or interface parity. Return complete replacement code only for the affected existing scope when code is requested.

Keep evidence state separate from action state: found, calculated, refreshed, uploaded, reconciled, approved and submitted require different evidence. Default to inspection/preparation. For an authorized write, reuse authorization that covers the exact target and payload, check preconditions and verify independently. If the outcome is uncertain or a write times out, read back before retrying; do not substitute locked or unapproved objects. Local validation helpers execute no enterprise writes.

Return the useful answer concisely: approved result, verified internal driver, relevant public benchmark, then material residual/blocker and next source. State only the statuses supported by evidence. Keep diagnostic detail in working context; do not add unsolicited sheets, audit tables, comments, queries, logs or process narration.

Keep operating sensitivity, accounting FX and allocation execution separate. Use approved internal rate/exposure/configuration records for finance results. Public FX is separately cited market context, never a replacement for booked FX, an approved planning rate, exposure or missing allocation membership.

## Establish the comparison

Record period/cutoff, scenario and assumption version, accounting/reporting perimeter, currency/unit, sign convention and source snapshots. Identify the approved rate's direction, rate type, observation/effective date, averaging method and use. Keep planning rate, realized rate, public reference and exposure as separate fields. A changed opportunity/risk perimeter is not an FX-rate effect.

## Review FX sensitivity

1. Align comparable sales and cost exposures and their currency pairs. Verify quote direction with a simple dimensional check. Do not invert a rate or convert an index without retaining the original series, formula and declared transformation.
2. Separate rate, volume, mix, price, scope and mitigation effects. State the bridge order and allocate interactions once. Reconcile the bridge to the observed total and retain the residual; do not attribute every difference to FX.
3. Label modeled sensitivity, approved forecast, realized accounting result and public benchmark separately. Keep base forecast and incremental opportunities/risks distinct. An indicator correlation is not proof of an internal driver.
4. When combining accounting and management extracts, identify ledger, currency type, document key, original versus replicated posting and elimination scope. Prevent duplicate postings while retaining unresolved identities. Do not assume a management view is the full accounting population.

## Review allocation preconditions

Validate the approved sender and receiver sets, member IDs, effective dates, weights and weight total, allocation basis, period, version, permissions and locks. An account description does not establish approved set membership. A saved cycle does not establish that it can run.

Treat a missing approved set, overlapping mapping, invalid weight, locked object or uncertain previous run as a blocker. Keep the approved configuration unchanged. Do not substitute a sender or normalize an incomplete allocation silently. Establish previous-run status from authorized evidence before considering a retry.

The default deliverable is a checked calculation or preflight result. Actual execution requires authorization covering the exact target and payload, validated preconditions and an available authorized host. If execution times out, inspect independent status/readback before retrying. A prepared configuration or successful preflight is not a posted allocation.

## Return

Give the requested sensitivity or preflight conclusion, verified internal drivers, relevant separately labeled benchmark, residual/blocker and next approved source. Keep routine checks internal; no audit sheets or configuration changes are required. State explicitly what was calculated and whether any action was actually executed.

## Edition record

Finance skills 1.4.4; gemini edition; source review 2026-11-25. This date records the package review, not the freshness of a user's business data.
