---
name: cash-working-capital
description: "Analyze operating cash, receivables, inventory and payables with reconciled working-capital metrics. Use for cash bridges, overdue aging, DSO/DIO/DPO, cash-conversion-cycle analysis, collection scenarios or short-term cash forecasts, with explicit stock-versus-flow and denominator checks."
---

# Cash and working capital

## Gemini edition

Use this skill in the employer-approved Gemini account. Work with the attached files and capabilities actually exposed in this conversation. Do not assume a SharePoint connector, a live Power BI model, direct Office editing, Gemini CLI, or access to the user's Windows filesystem. Keep company content in approved accounts and locations.

Use available file and calculation tools for complete accessible inputs. Skill scripts must not depend on internet access, authenticated APIs, or package installation. Keep SQL in Markdown code blocks. An optional Python workflow runs separately on the work PC unless an available Gemini calculation tool actually executes it. Treat all proposed scripts, queries and output files as unexecuted until there is observable evidence; request the resulting control totals or artifact for follow-up analysis.

Do not promise that a skill can run with Canvas or Deep Research. If one of those separate tools is needed, provide an explicit task brief and source requirements for that workflow, then work from the result the user returns. Use primary citations only from sources actually accessed.

Use native Skills if the work account exposes Customize > Skills. Google documentation currently differs on work-account rollout, so check the account rather than infer availability. If Skills is absent but Gems is available, place the workflow in the Gem's Instructions; a knowledge attachment alone does not make it an instruction. Otherwise paste the task instructions into an approved conversation. Imported skills and Gem instructions do not automatically track GitHub; replace the existing copy after an update.

Build a management analysis using supplied balances, transactions and approved KPI definitions. Preserve the reporting boundary and distinguish observed cash movements, balance movements and modeled opportunities. Calculate with available tools when possible; otherwise provide formulas and mark results uncomputed. Do not invent bank balances, payment dates, contractual terms or missing source populations.

## Set the basis

Confirm the as-of date, analysis period, actual calendar-day count or approved convention, entities, currencies, consolidation boundary and unit scale. Establish whether balances are gross/net of tax, intercompany, impairment, factoring, disputed items, advances or credit notes. Match the same scope in each numerator and denominator. Ask for the approved KPI definition when alternatives materially change the result.

Inventory cash opening/closing balances and movements; AR/AP opening, closing and intermediate snapshots if available; invoice/payment details; credit sales; COGS; credit purchases; and inventory data. Record file version, source locator and extract time. Keep confidential balances and account details within the approved work environment.

## Reconcile before interpreting

1. **Cash bridge.** Reconcile opening cash plus receipts minus payments plus separately identified translation/reclassification effects to closing cash. Show unreconciled differences. Transfers between accounts within the same reporting boundary cancel in the consolidated bridge; do not treat both legs as external funding or operating cash. Keep restricted cash and cash equivalents aligned with the supplied policy and scope.
2. **Balance bridges.** Reconcile AR, inventory and AP opening balances to closing balances using the relevant transaction classes. Separate cash settlement from non-cash FX, write-offs, reclassifications, acquisitions/disposals and scope changes. A balance-sheet movement alone is not proof of cash generated or spent.
3. **Working capital.** If the agreed management definition is trade AR plus inventory minus trade AP, show each component and any explicitly included additions. Under a constant scope, increases in AR/inventory generally use cash and increases in AP generally release cash; quantify this only after separating non-cash and scope effects. Do not present this approximation as a completed statutory cash-flow statement.

## Calculate comparable metrics

Use the organization's approved method. When a conventional period-ratio method is requested, state the formulas and all substitutions:

| Metric | Period-ratio calculation | Required alignment |
|---|---|---|
| DSO | Average trade AR / credit sales in the period × days in the period | Match entities, currency and tax/sales scope; cash sales are not credit sales |
| DIO | Average inventory / COGS in the period × days in the period | Match inventory population and cost basis |
| DPO | Average trade AP / credit purchases in the period × days in the period | Purchases and COGS differ; label COGS as a proxy if used |
| Cash conversion cycle | DSO + DIO − DPO | Use comparable periods, days and populations |

Use time-weighted or sufficiently frequent balances when available and appropriate. If only opening and closing balances exist, label their arithmetic mean a two-point approximation and note seasonality or intra-period volatility. If only closing balances exist, report an explicitly named end-balance proxy; do not call it average-balance DSO. Do not average entity ratios to obtain a group ratio: aggregate aligned numerator balances and denominator flows first, using a consistent currency basis.

Do not sum monthly balance snapshots as though they were transactions. Do not use a monthly flow with an annual-day multiplier unless the flow is annualized consistently. Check zero, negative or implausible denominators; return not meaningful with an explanation when the metric's economic interpretation fails. Retain the underlying amounts even when the ratio is suppressed. Do not substitute zero for missing data.

## Analyze aging and forecast cash

Age invoices from the specified due-date or invoice-date basis and disclose which was used. Define bucket boundaries, the as-of timezone/date, treatment of partial payments, credits, disputes and missing due dates. Reconcile aging balances to the same-date subledger and explain differences from the GL. Do not assign missing terms from a customer name.

For a collection or payment forecast, use open-item amounts, agreed timing assumptions and explicit delay scenarios. Show opening cash, dated receipts/payments, financing assumptions if supplied, and closing cash for each interval. A forecast must distinguish contractual due dates from expected payment dates and committed flows from assumptions. Avoid double-counting collections already received or invoices already settled in the opening snapshot.

Translate a days improvement into a potential working-capital effect only with a stated stable flow basis. For example, a modeled DSO reduction multiplied by aligned daily credit sales is a sensitivity estimate; it is not evidence that cash has been collected. Do not add that estimate to an invoice-level collection forecast if the same improvement is already modeled there.

## Deliver

- A cash and working-capital bridge with residuals, FX and non-cash movements visible.
- A KPI table with formulas, numerator/denominator scope, balance-average method, day count and limitations.
- Reconciled aging, major drivers and actionable exception populations.
- If requested, a dated cash scenario with assumptions and headroom against a user-supplied minimum.
- Source locators, calculation status and checks still needed.

Example request: “Compare October and November working capital using these balances and credit sales. Calculate DSO, DIO and DPO with the available average balances, reconcile the aging, and estimate a five-day DSO improvement without treating it as realized cash.”

## Edition record

Finance skills 1.0.0; gemini edition; source review 2026-11-25. This date records the package review, not the freshness of a user's business data.
