# Start here

Finance skills 1.9.1 · reviewed 2026-11-27

This download contains 30 finance skills for Microsoft 365 Copilot and Gemini, with 60 individual native-import packages.

This outer ZIP is a transport download, not one installable skill. Extract it first; upload an individual package from packages/copilot/ or packages/gemini/.

## Extract and choose

1. In Windows File Explorer, extract this outer ZIP to a folder.
2. Read the selected assistant's guide below.
3. Import the individual skill ZIPs you need. Each contains one root SKILL.md.

**Copilot:** [setup guide](https://github.com/mim1hat-prog/finance-skills/blob/main/docs/COPILOT.md). Select individual files under packages/copilot/ for a supported Chat or Agent Builder import. For an Excel or PowerPoint folder workflow, copy selected matching-name folders from editions/copilot/ into the location opened by the app, then follow its sync and Refresh steps.

**Gemini:** [setup guide](https://github.com/mim1hat-prog/finance-skills/blob/main/docs/GEMINI.md). Import individual files under packages/gemini/ into native Skills. If your account uses the Gem fallback, the corresponding editions/gemini-gems/ text goes in Instructions; follow the guide for that account.

## Excel agent instructions

profiles/excel-agent-instructions.txt is the plain-text body of the canonical excel-agent-core skill. Copy it into an available Excel agent's instruction field when that setup accepts text, or use the individual skill package through a supported import.

## Verify and update

manifest.json lists the exact path, size and SHA-256 of every other file in this bundle. The manifests under packages/ describe the individual native skill packages.

This outer ZIP is a download-and-transport bundle. Native imports still happen one skill at a time; extracting or copying files does not prove automatic activation. Use the host's replacement or Refresh flow for later updates and verify a representative task.

[Windows guide](https://github.com/mim1hat-prog/finance-skills/blob/main/docs/WINDOWS.md) · [Update guide](https://github.com/mim1hat-prog/finance-skills/blob/main/docs/UPDATES.md)
