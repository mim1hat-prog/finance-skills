---
name: provision-reconciliation
description: "Reconcile provision or warranty movements across a frozen overview, detailed calculation, staged upload and reporting readback. Use for unexplained additions, releases, utilization or closing differences, conflicting forecast versions, and incomplete case-owner confirmations."
---

# Provision and warranty reconciliation

## Gemini edition

Use this skill in the employer-approved Gemini account. Work with the attached files and capabilities actually exposed in this conversation. Do not assume a SharePoint connector, a live Power BI model, direct Office editing, Gemini CLI, or access to the user's Windows filesystem. Keep company content in approved accounts and locations.

Use available file and calculation tools for complete accessible inputs. Skill scripts must not depend on internet access, authenticated APIs, or package installation. Keep SQL in Markdown code blocks. An optional Python workflow runs separately on the work PC unless an available Gemini calculation tool actually executes it. Treat all proposed scripts, queries and output files as unexecuted until there is observable evidence; request the resulting control totals or artifact for follow-up analysis.

Do not promise that a skill can run with Canvas or Deep Research. If one of those separate tools is needed, provide an explicit task brief and source requirements for that workflow, then work from the result the user returns. Use primary citations only from sources actually accessed.

Use native Skills if the work account exposes Customize > Skills. Google documentation currently differs on work-account rollout, so check the account rather than infer availability. If Skills is absent but Gems is available, place the workflow in the Gem's Instructions; a knowledge attachment alone does not make it an instruction. Otherwise paste the task instructions into an approved conversation. Imported skills and Gem instructions do not automatically track GitHub; replace the existing copy after an update.

## Shared workflow controls

Use all relevant available, authorized capabilities needed for the objective. For company questions, retrieve enterprise evidence first. Before treating a missing search result as missing data, inspect the source content and try a materially different query, period, linked reference or responsible-source route. Continue while another available step can resolve a material uncertainty; do not repeat unchanged searches or browse unrelated sources to inflate coverage. Use an available deeper research/reasoning mode when appropriate and supported; instructions cannot select a hidden mode, grant permissions or exceed platform limits.

Independently recheck consequential results with a second calculation, source record or alternative method. Rereading the same answer is not an independent check. Investigate contradictions and failed checks, correct them, then rerun the affected checks. Finish when the requested scope is complete and material claims are supported, or report the specific unresolved gap after useful retrieval routes are exhausted. At a host limit, preserve the objective, source locators, versions, decisions and pending work in a compact continuation; never claim that unseen work was completed. Keep this diligence internal and the final response precise.

Keep three streams distinct: approved internal figures; internal workflow status; public benchmarks. An internal blank stays unresolved until the authorized source supplies it. A benchmark can challenge an assumption but cannot become an actual, approved forecast, booked rate, mapping, case confirmation or close receipt.

Before comparing numbers, align period and cutoff/timezone, scenario and version, entities, accounting/reporting basis, currency/unit, sign convention and source snapshot. Keep a requested frozen submission separate from newer working files. Record exact source locations and what each source establishes in working context; do not create an audit artifact merely to store these checks.

Validate business keys, join cardinality, effective dates, gross movements and detailed coordinates as well as totals. Normalize units/signs only from explicit declarations. Calculate residuals at source precision and use an approved, versioned, effective tolerance. An unexplained residual is not rounding by default.

Preserve the baseline workbook/query, protected records, ordered names/types, formulas, load targets, add-in regions and downstream consumers outside the requested change. Successful refresh alone does not establish population or interface parity. Return complete replacement code only for the affected existing scope when code is requested.

Keep evidence state separate from action state: found, calculated, refreshed, uploaded, reconciled, approved and submitted require different evidence. Match the action to the request: inspect or prepare when that is the scope; carry out an authorized change when the required capability and preconditions are present. Reuse authorization covering the exact target and payload, and verify the result independently. If the outcome is uncertain or a write times out, read back before retrying; do not substitute locked or unapproved objects. Local validation helpers execute no enterprise writes.

Return the useful answer concisely: approved result, verified internal driver, relevant public benchmark, then material residual/blocker and next source. State only the statuses supported by evidence. Keep diagnostic detail in working context; do not add unsolicited sheets, audit tables, comments, queries, logs or process narration.

Answer the requested movement at the requested version. A plausible explanation for additions does not answer a utilization question. Keep the current assignment within available authorized sources and the organization's supplied accounting definitions.

## Establish the comparison

Identify the period, cutoff, scenario/version, entity/product or case scope, currency and scale, sign convention, source snapshots and requested output. Distinguish a frozen submission, the calculation supporting it, its staged payload and the reporting readback. A newer working forecast cannot prove that an earlier submission was corrected.

Retrieve relevant approved case records, owner confirmations, calculation formulas, source extracts and submission evidence before assuming a cause. Keep case owner, requested scope and confirmation date with the working evidence. Distinguish not requested, awaiting confirmation, confirmed none and confirmed cases. No received cases does not establish confirmed none. An approved numeric zero is separate from whether every required owner was asked.

## Reconcile every movement

1. Preserve the existing workbook and report layout. Locate the source formula and inputs for the requested value; trace references across sheets, named ranges and mappings without adding audit tabs or comments.
2. Keep opening, additions, releases, utilization, other movements and closing separate. Define signs explicitly and calculate closing from signed movements. Retain both the closing residual and each movement's difference between artifacts.
3. Check gross components and product/case/entity detail. Offsetting additions and utilization differences can hide behind a matching closing balance. Do not net unrelated items to call the requested movement reconciled.
4. Test explanations against the entire observed difference. Quantify scope, period, formula reference, mapping, version and declared FX-basis effects separately; retain the unexplained residual at source precision. Apply the provided effective tolerance without inventing a balancing adjustment.
5. Distinguish provision movement from a claim's operational status, supplier responsibility, invoice, payment, settlement and P&L effect. Use supplied approved policy and evidence for those relationships; a public recall notice does not establish any of them.
6. When the required reporting system is unavailable, reconcile the provided export and label its snapshot and access limit. A cached workbook or staged upload is not a verified live readback or submission.

## Complete the request

Return the requested additions/utilization/closing answer with concise source references, remaining residual and the specific source or owner confirmation needed. Produce a movement table only if the requested reconciliation needs it; do not append a separate audit report. State evidence and action separately, for example, "calculation reconciled; upload prepared; submission not verified."

The local workflow checker can validate independently supplied synthetic or authorized export records; it cannot retrieve private cases, determine accounting policy, refresh a workbook or submit a report. Preserve company configuration and run results in the approved environment.

## Example request

"Explain the utilization difference between the frozen forecast, its detailed calculation and the reporting export. Check additions separately, preserve the existing workbook and show any residual that the evidence does not explain."

## Edition record

Finance skills 1.6.0; gemini edition; source review 2026-11-25. This date records the package review, not the freshness of a user's business data.
